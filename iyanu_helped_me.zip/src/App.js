// CSS
import './css/App.css';

// COMPONENTS
import Signup from './components/SignupPage';

function App() {
  return (
    <div className="App">
      <div className="main">
          <Signup />
      </div>
    </div>
  );
}

export default App;
